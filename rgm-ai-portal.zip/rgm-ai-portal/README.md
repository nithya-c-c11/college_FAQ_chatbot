
# RGM AI Portal

Next.js 15 + TypeScript + Prisma + PostgreSQL + Clerk + OpenAI + ShadCN UI

## Run
npm install
npm run dev
