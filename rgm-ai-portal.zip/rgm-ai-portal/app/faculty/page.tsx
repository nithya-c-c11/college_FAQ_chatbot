
const faculty = [
  {
    name: "Dr. Bihari Agarwal",
    dept: "Civil Engineering"
  },
  {
    name: "Dr. T Jayachandra Prasad",
    dept: "ECE"
  }
];

export default function FacultyPage() {
  return (
    <div className="p-10">
      <h1 className="text-5xl font-bold mb-10">Faculty</h1>

      <div className="grid md:grid-cols-2 gap-6">
        {faculty.map((f) => (
          <div
            key={f.name}
            className="bg-white/20 p-6 rounded-2xl"
          >
            <h2 className="text-2xl">{f.name}</h2>
            <p>{f.dept}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
