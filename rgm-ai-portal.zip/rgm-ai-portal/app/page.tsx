
import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen p-10">
      <nav className="flex justify-between bg-white/20 p-4 rounded-2xl backdrop-blur">
        <h1 className="text-3xl font-bold">RGMCET</h1>

        <div className="flex gap-6">
          <Link href="/">Home</Link>
          <Link href="/departments">Departments</Link>
          <Link href="/faculty">Faculty</Link>
          <Link href="/ask-rgm">Ask RGM AI</Link>
        </div>
      </nav>

      <section className="mt-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-7xl font-bold">Welcome to RGMCET</h1>

          <p className="mt-6 text-xl">
            AI-powered campus information portal.
          </p>

          <div className="mt-8 flex gap-4">
            <Link
              href="/ask-rgm"
              className="bg-white text-blue-500 px-6 py-3 rounded-xl"
            >
              Ask RGM AI
            </Link>

            <Link
              href="/departments"
              className="border px-6 py-3 rounded-xl"
            >
              Explore Campus
            </Link>
          </div>
        </div>

        <div>
          <img
            src="https://www.rgmcet.edu.in/images/slider/1.jpg"
            className="rounded-3xl"
          />
        </div>
      </section>
    </main>
  );
}
