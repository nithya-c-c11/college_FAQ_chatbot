
"use client";

import { useState } from "react";

export default function AskRGM() {
  const [question, setQuestion] = useState("");
  const [response, setResponse] = useState("");

  const askAI = async () => {
    const res = await fetch("/api/ai", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ question })
    });

    const data = await res.json();
    setResponse(data.answer);
  };

  return (
    <div className="p-10">
      <h1 className="text-5xl font-bold mb-10">Ask RGM AI</h1>

      <textarea
        className="w-full p-4 rounded-xl text-black"
        rows={5}
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
      />

      <button
        onClick={askAI}
        className="mt-4 bg-white text-blue-500 px-6 py-3 rounded-xl"
      >
        Ask
      </button>

      <div className="mt-10 bg-white/20 p-6 rounded-2xl">
        {response}
      </div>
    </div>
  );
}
