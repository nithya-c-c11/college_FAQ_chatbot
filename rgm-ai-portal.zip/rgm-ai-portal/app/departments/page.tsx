
const departments = [
  "CSE",
  "ECE",
  "EEE",
  "Mechanical",
  "Civil",
  "MBA",
  "MCA"
];

export default function Departments() {
  return (
    <div className="p-10">
      <h1 className="text-5xl font-bold mb-10">Departments</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {departments.map((dept) => (
          <div
            key={dept}
            className="bg-white/20 p-6 rounded-2xl backdrop-blur"
          >
            <h2 className="text-2xl font-semibold">{dept}</h2>
          </div>
        ))}
      </div>
    </div>
  );
}
